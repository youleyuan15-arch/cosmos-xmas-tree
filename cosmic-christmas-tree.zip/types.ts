
export type ShapeType = 'tree' | 'nebula' | 'text' | 'clover';
